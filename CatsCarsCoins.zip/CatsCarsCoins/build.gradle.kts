// build.gradle.kts (project root)
// Top-level build file where you can add configuration options common to all sub-projects/modules.

// AGP 9 built-in Kotlin: KGP is on the build classpath at a version the plugin
// resolver can't see, so KGP-family sub-plugins cannot be requested WITH a
// version. Each sub-plugin is its OWN artifact — every one :app uses is
// declared here at a KNOWN version. Modules apply them with no version.
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:${libs.versions.kotlin.get()}")
        classpath("org.jetbrains.kotlin:kotlin-serialization:${libs.versions.kotlin.get()}")
        // AGP-documented coordinates for pinning a higher KSP than AGP's default
        classpath("com.google.devtools.ksp:symbol-processing-gradle-plugin:${libs.versions.ksp.get()}")
    }
}

plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
}