// coins/ui/CoinsScreen.kt
// CatsCarsCoins — spec 24.2.45. Complete file.
// Change from 24.2.36: private toUsdDisplay and CENTS_PER_DOLLAR deleted —
// promoted to coins/ui/UsdDisplay.kt (24.2.44, rule of two: the coin toast
// is the second user). Same package: call sites unchanged, no import.
// APPLY WITH 24.2.44 — the two files land together.
package com.icodeforyou.catscarscoins.coins.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.icodeforyou.catscarscoins.coins.domain.Coin
import com.icodeforyou.catscarscoins.preferences.buttonFontSize
import com.icodeforyou.catscarscoins.preferences.hapticsEnabled
import com.icodeforyou.catscarscoins.ui.components.AppButton
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.koin.androidx.compose.koinViewModel

private val SCREEN_PADDING = 16.dp
private val ROW_VERTICAL_PADDING = 8.dp

/** Thread-safe; system zone applied at format time. */
private val TIMESTAMP_FORMATTER: DateTimeFormatter =
    DateTimeFormatter.ofPattern("MMM d · HH:mm:ss", Locale.US)

/**
 * Coins destination (Phase 2 UI): the stored BTC-USD samples, newest
 * first (repository guarantee), with the §19 Refresh action. First §17
 * call site — the AppButton's behavior params are read from the global
 * accessors at the call site, per the spec's accessor table.
 */
@Composable
fun CoinsScreen(
    viewModel: CoinsViewModel = koinViewModel(),
) {
    val coins by viewModel.coins.collectAsStateWithLifecycle()

    CoinsContent(
        coins = coins,
        onRefresh = viewModel::onRefresh,
    )
}

@Composable
private fun CoinsContent(
    coins: List<Coin>,
    onRefresh: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(SCREEN_PADDING),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text = "BTC-USD", style = MaterialTheme.typography.titleLarge)
            AppButton(
                text = "Refresh",
                onClick = onRefresh,
                useHaptics = hapticsEnabled(),
                fontSize = buttonFontSize(),
            )
        }

        if (coins.isEmpty()) {
            EmptyState()
        } else {
            SampleList(coins = coins)
        }
    }
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = "No samples yet",
            style = MaterialTheme.typography.titleMedium,
        )
        Text(
            text = "Polling is paused by default — unpause it in Settings, or tap Refresh for one sample now.",
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun SampleList(coins: List<Coin>) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(items = coins, key = { coin -> coin.id }) { coin ->
            CoinRow(coin = coin)
            HorizontalDivider()
        }
    }
}

@Composable
private fun CoinRow(coin: Coin) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ROW_VERTICAL_PADDING),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = coin.amountCents.toUsdDisplay(),
            style = MaterialTheme.typography.bodyLarge,
        )
        Text(
            text = coin.recordedAtEpochMillis.toTimestampDisplay(),
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

private fun Long.toTimestampDisplay(): String =
    TIMESTAMP_FORMATTER.format(
        Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()),
    )