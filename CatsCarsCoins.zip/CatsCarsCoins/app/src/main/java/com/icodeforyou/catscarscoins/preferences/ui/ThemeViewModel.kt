// preferences/ui/ThemeViewModel.kt
// CatsCarsCoins — spec 24.2.32. Complete file.
// Change from 24.1.8: private SUBSCRIPTION_STOP_TIMEOUT_MS deleted in favor
// of the shared ui.SUBSCRIPTION_STOP_TIMEOUT_MS (promoted 24.2.30 at the
// third StateFlow ViewModel). 24.1.8's lambda-transform correction retained.
package com.icodeforyou.catscarscoins.preferences.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.icodeforyou.catscarscoins.preferences.domain.AppPreferences
import com.icodeforyou.catscarscoins.preferences.domain.PreferencesRepository
import com.icodeforyou.catscarscoins.preferences.domain.ThemeMode
import com.icodeforyou.catscarscoins.ui.SUBSCRIPTION_STOP_TIMEOUT_MS
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/**
 * Spec §18 pipeline, middle piece: DataStore → StateFlow → MaterialTheme.
 * Sole responsibility: expose the persisted [ThemeMode] as state (SRP).
 * StateFlow's equality conflation guarantees non-theme preference writes
 * never emit — the theme tree does not recompose when haptics or polling
 * change (verified by 24.1.7).
 */
class ThemeViewModel(
    preferencesRepository: PreferencesRepository,
) : ViewModel() {

    val themeMode: StateFlow<ThemeMode> = preferencesRepository.preferences
        .map { preferences -> preferences.themeMode }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(SUBSCRIPTION_STOP_TIMEOUT_MS),
            initialValue = AppPreferences.DEFAULTS.themeMode,
        )
}