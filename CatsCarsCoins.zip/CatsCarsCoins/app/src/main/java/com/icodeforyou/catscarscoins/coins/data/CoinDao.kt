// coins/data/CoinDao.kt
// CatsCarsCoins — spec 24.2.4. Complete file.
package com.icodeforyou.catscarscoins.coins.data

import androidx.room3.Dao
import androidx.room3.Insert
import androidx.room3.Query
import kotlinx.coroutines.flow.Flow

/**
 * Room 3 DAO for the coins table (spec: FIFO 500-row cap via trimToLimit,
 * newest-first observation). Coroutine-first per Room 3 — every non-Flow
 * member is suspend.
 *
 * Ordering ties: recorded_at is epoch millis, so two samples in the same
 * millisecond are possible; id DESC breaks the tie deterministically in
 * both the observation and the trim's keep-set.
 */
@Dao
interface CoinDao {

    @Query("SELECT * FROM coins ORDER BY recorded_at DESC, id DESC")
    fun observeAll(): Flow<List<CoinEntity>>

    @Insert
    suspend fun insert(entity: CoinEntity)

    /**
     * FIFO trim (spec: cap 500): keeps the newest [limit] rows, deletes
     * the rest — oldest go first. The keep-set subquery uses the same
     * ordering as [observeAll], so what the list shows and what survives
     * the trim can never disagree.
     */
    @Query(
        """
        DELETE FROM coins
        WHERE id NOT IN (
            SELECT id FROM coins
            ORDER BY recorded_at DESC, id DESC
            LIMIT :limit
        )
        """,
    )
    suspend fun trimToLimit(limit: Int)

    /** Reset App hook (spec §16) — no confirm anywhere, including here. */
    @Query("DELETE FROM coins")
    suspend fun deleteAll()
}