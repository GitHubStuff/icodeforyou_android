// ui/theme/Theme.kt
// CatsCarsCoins — spec 24.1.10. Complete file.
// Change from 24.0.5-16: AppTheme now takes a required themeMode: ThemeMode
// instead of darkTheme: Boolean = isSystemInDarkTheme(). The component
// receives a plain value and has no knowledge of preferences — the same
// rule the spec fixes for buttons (§17).
package com.icodeforyou.catscarscoins.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import com.icodeforyou.catscarscoins.preferences.domain.ThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = Purple80,
    secondary = PurpleGrey80,
    tertiary = Pink80,
)

private val LightColorScheme = lightColorScheme(
    primary = Purple40,
    secondary = PurpleGrey40,
    tertiary = Pink40,
)

/**
 * App-wide Material3 theme (spec §18): explicit light/dark palettes,
 * dynamic color deliberately unsupported — palettes stay deterministic
 * across devices, which a reference blueprint requires.
 *
 * [themeMode] is required, no default: the caller observes the persisted
 * preference (ThemeViewModel) and passes a plain value. SYSTEM resolves
 * here via [isSystemInDarkTheme] — a composition-time concern; a device
 * dark/light flip delivers a configuration change, this recomposes, and
 * the theme follows live.
 */
@Composable
fun AppTheme(
    themeMode: ThemeMode,
    content: @Composable () -> Unit,
) {
    val darkTheme = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography = Typography,
        content = content,
    )
}