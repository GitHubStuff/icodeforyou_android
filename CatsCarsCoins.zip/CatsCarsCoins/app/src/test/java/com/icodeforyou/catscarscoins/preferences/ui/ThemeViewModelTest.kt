// preferences/ui/ThemeViewModelTest.kt
// CatsCarsCoins — spec 24.1.19. Complete file.
// Change from 24.1.7: nested fake and inline Dispatchers.setMain plumbing
// replaced by the shared FakePreferencesRepository (24.1.17) and
// MainDispatcherRule (24.1.18). Tests and assertions unchanged.
package com.icodeforyou.catscarscoins.preferences.ui

import app.cash.turbine.test
import com.icodeforyou.catscarscoins.preferences.domain.AppPreferences
import com.icodeforyou.catscarscoins.preferences.domain.FakePreferencesRepository
import com.icodeforyou.catscarscoins.preferences.domain.ThemeMode
import com.icodeforyou.catscarscoins.testsupport.MainDispatcherRule
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

class ThemeViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    @Test
    fun `initial theme is the spec default`() = runTest {
        val viewModel = ThemeViewModel(FakePreferencesRepository())

        assertEquals(AppPreferences.DEFAULTS.themeMode, viewModel.themeMode.value)
    }

    @Test
    fun `theme changes in the repository reach themeMode`() = runTest {
        val repository = FakePreferencesRepository()
        val viewModel = ThemeViewModel(repository)

        viewModel.themeMode.test {
            assertEquals(ThemeMode.DARK, awaitItem())

            repository.setThemeMode(ThemeMode.LIGHT)
            assertEquals(ThemeMode.LIGHT, awaitItem())

            repository.setThemeMode(ThemeMode.SYSTEM)
            assertEquals(ThemeMode.SYSTEM, awaitItem())
        }
    }

    @Test
    fun `non-theme preference changes emit nothing`() = runTest {
        val repository = FakePreferencesRepository()
        val viewModel = ThemeViewModel(repository)

        viewModel.themeMode.test {
            assertEquals(ThemeMode.DARK, awaitItem())

            repository.setHapticsEnabled(false)
            repository.setPollingPaused(false)
            repository.setPollingIntervalSeconds(30)
            expectNoEvents()
        }
    }
}